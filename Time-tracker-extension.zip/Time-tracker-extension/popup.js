document.addEventListener("DOMContentLoaded", async () => {
  const listEl = document.getElementById("list");
  const exportBtn = document.getElementById("export");
  const resetBtn = document.getElementById("reset");

  function render(totals) {
    listEl.innerHTML = "";
    const keys = Object.keys(totals).sort((a,b) => totals[b]-totals[a]);
    if (keys.length === 0) {
      listEl.innerText = "Brak danych";
      return;
    }
    const ul = document.createElement("ul");
    for (const k of keys) {
      const li = document.createElement("li");
      li.textContent = `${k} — ${Math.round(totals[k])} s`;
      ul.appendChild(li);
    }
    listEl.appendChild(ul);
  }

  function getTotals() {
    chrome.runtime.sendMessage({ type: "getTotals" }, (res) => {
      render(res.totals || {});
      // store lastTotals for export
      window.lastTotals = res.totals || {};
    });
  }

  exportBtn.addEventListener("click", () => {
    const totals = window.lastTotals || {};
    let csv = "domain,seconds\n";
    for (const d in totals) {
      csv += `${d},${Math.round(totals[d])}\n`;
    }
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "time_report.csv";
    a.click();
    URL.revokeObjectURL(url);
  });

  resetBtn.addEventListener("click", () => {
    if (!confirm("Czy na pewno zresetować zebrane dane?")) return;
    chrome.runtime.sendMessage({ type: "reset" }, (res) => {
      getTotals();
    });
  });

  getTotals();
});
